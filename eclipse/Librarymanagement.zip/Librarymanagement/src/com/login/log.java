package com.login;

import java.sql.Statement;
import java.sql.Connection;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import code.databasecon;

@WebServlet("/log")
public class log extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) {
		String i=request.getParameter("email");
		String j=request.getParameter("pswd");
		Connection con = databasecon.initializeDatabase();
	}
}
